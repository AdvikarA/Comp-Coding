#include <fstream>
using namespace std;
int main() {
    ifstream fin("shell.in");
    ofstream fout("shell.out");
    int n; 
    fin >> n; 
    int count = 0; 
    int maxcount = 0; 
    int a[n], b[n], g[n]; 
    for(int i = 0; i < n; i++){
        fin >> a[i];
        fin >> b[i];
        fin >> g[i]; 
    }
    for(int location = 1; location <= 3; location++){
        count = 0; 
        for(int i = 0; i < n; i++){
            if(a[i] == location){
                location = b[i]; 

            }
            else if(b[i] == location){
                location = a[i]; 
            }
            if(g[i] == location){
                count++; 
            }
        }
        if(count > maxcount){
            maxcount = count; 
        }
    }
    fout << count; 
}