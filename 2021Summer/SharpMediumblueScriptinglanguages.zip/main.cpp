#include <iostream>
using namespace std;
int main() {
  int n; 
  cin >> n; 
  if(n < 3){
    cout << 1
  }
  else{
    cout << 4; 
  }
}