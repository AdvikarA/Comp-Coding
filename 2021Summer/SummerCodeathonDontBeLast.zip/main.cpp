#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
using namespace std;
int main() {
    int n; 
    cin >> n; 
    string cows[7] = {"Bessie", "Elsie", "Daisy", "Gertie", "Annabelle", "Maggie", "Henrietta"};
    map<string, int>m;
    for(int i = 0; i < 7; i++){
        m[cows[i]] = 0;
    }
    for(int i = 0; i < n; i++){
        string s; 
        int milk;
        cin >> s >> milk; 
        m[s] = milk; 
    }
    int smallest = 100; 
    int smol; 
    for(int i = 0; i < 7; i++){
        if(m[cows[i]] < smallest){
            smallest = m[cows[i]]; 
            smol = i;  
        }
    }
    smallest = 100; 
    string smol2;
    int count = 1; 
    for(int i = 0; i < 7; i++){
        if(i != smol){
            if(m[cows[i]] < smallest){
                smallest = m[cows[i]]; 
                smol2 = cows[i];
                count = 1;    
            }
            else if(m[cows[i]] == smallest){
                count++; 
            }
        }
    }
    if(count == 1){
        cout<<smol2<<"\n";
    }
    else{
        cout << "Tie\n"; 
    }
}