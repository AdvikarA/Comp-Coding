#include <iostream>
#include <string>
#include <map>
using namespace std; 
int main() {
    string years[12] = {"Ox", "Tiger", "Rabbit", "Dragon", "Snake", "Horse", "Goat", "Monkey", "Rooster", "Dog", "Pig", "Rat"};
    int n;
    string words[8]; 
    cin >> n;
    int yearindex = 0; 
    string cowa, born, in, relation, animal, year, from, cowb; 
    map<string,int> whenborn;  
    whenborn["Bessie"] = 1000; 
    int cowplace = 0; 
    for (int t = 0; t < n; t++){
        cin >> cowa >> born >> in >> relation >> animal >> year >> from >> cowb;
        whenborn[cowa] = whenborn[cowb]; 
        cowplace = yearindex; 
        for(int i = 0; i < 12; i++){
            //cout << animal << " " << years[i] << " " << yearindex << "\n";
            if(animal == years[i]){
                yearindex = i; 
            }
            
        }  
        if(relation == "previous"){
            whenborn[cowa] -= (12 - abs(cowplace - yearindex));
            //cout << (12 - abs(cowplace - yearindex));
        }
        if(relation == "next"){
            whenborn[cowa] += (12 - abs(cowplace - yearindex)); 
        }
        
        //cout << whenborn[cowa] << " " << "yearindex " << yearindex << "\n";
        if(cowa == "Elsie"){
            cout << abs(1000-(whenborn["Elsie"]));
        }
    }
}
