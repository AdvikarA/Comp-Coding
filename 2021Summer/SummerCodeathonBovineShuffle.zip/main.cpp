#include <iostream>
using namespace std; 
int main() {
    int N; 
    cin >> N; 
    int shuf[N]; 
    int tempcows[N]; 
    for(int i = 1; i <= N; i++){
        cin >> shuf[i]; 
    }
    int cows[N]; 
    for(int i = 1; i <= N; i++){
        cin >> cows[i]; 
        tempcows[i] = cows[i];
    }
    for(int i = 1; i <= N; i++){
        cows[shuf[i]] = tempcows[i];
    }
    for(int i = 1; i <= N; i++){
        cout << cows[i] << "\n";
    }
}
