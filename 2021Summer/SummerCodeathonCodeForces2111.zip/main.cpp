#include <iostream>
#include <map>
using namespace std; 
typedef long long ll; 
int main() {
    map<ll, ll>pop; 
    pop[6] = 15;
    pop[8] = 20; 
    pop[10] = 25; 
    ll n; 
    cin>>n; 
    for(ll i = 0; i < n; i++){
        ll s; 
        ll l = 0; 
        ll me = 0; 
        ll ss = 0; 
        cin >> s;
        ll m = 9223372036854775807;
        bool solved = false; 
        if(solved == false){
            if(s < 6){
                cout << 15; 
                solved = true; 
            }
        }
        if(solved == false){
        
            if(s % 6 == 0){
                cout << 15*s/6; 
                solved = true; 
            }
        }
        if(solved == false){

            if(s % 8 == 0){
                cout<< 20*s/8; 
                solved = true; 
            }
        }
        if(solved == false){

            if(s % 10 == 0){
                cout << 25*s/10;
                solved = true; 
            }
        }
        if(solved == false){

            if (s % 6 > 0)
            {
                if(solved == false){

                    if(s % 6 < 3){
                        cout << 15*(s/6 - 1) + 20; 
                        solved = true; 
                    }
                }
                if(solved == false){

                    if(s % 6 == 5){
                        cout << 15*((s+1)/6); 
                        solved = true; 
                    }
                }
                if(solved == false){

                    if(s % 6 == 4){
                        cout << 15*(s/6 - 1)+25; 
                        solved = true; 
                    }
                }
            }
        }
        if(solved == false){

            if (s % 8 > 0)
            {
                if(solved == false){

                    if(s % 8 < 3){
                        cout << 20*(s/8 - 1) + 25; 
                        solved = true; 
                    }
                }
                if(solved == false){

                    if(s % 8 == 7){
                        cout << 20*((s+1)/8); 
                        solved = true; 
                    }
                }
                if(solved == false){

                    if(s % 8== 4){
                        cout << 20*(s/8 - 1)+30; 
                        solved = true; 
                    }
                }
            }
        }
        if(solved == false){

            if (s % 10 > 0)
            {
                if(solved == false){

                    if(s % 10 < 3){
                        cout << 25*(s/10 - 1) + 30; 
                        solved = true; 
                    }
                }
                if(solved == false){

                    if(s % 10 == 9){
                        cout << 25*((s+1)/10); 
                        solved = true; 
                    }
                }
                if(solved == false){
                    if(s % 10 == 4){
                        cout << 25*(s/10 - 1)+30; 
                        solved = true; 
                    }
                }
            }
        }
        cout << "\n";
    }
}