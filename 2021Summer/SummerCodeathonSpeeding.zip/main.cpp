#include <iostream>
#include <fstream>
using namespace std; 
int main() {
  ifstream fin("speeding.in");
  ofstream fout("speeding.out");
  int N, M; 
  int ans = 0; 
  int distance = 0; 
  fin >> N >> M; 
  int limits[100]; 
  int segment, limit; 
  int bsegs, bspeed; 

  
  for(int i = 0; i < N; i++){
      fin >> segment >> limit; 
      for(int j = 0; j < segment; j++){
          limits[distance] = limit;
          distance++; 
      }
  }
  int speeds[100]; 
  int dist = 0; 
  for(int i = 0; i < M; i++){
      fin >> bsegs >> bspeed; 
      for(int j = 0; j < bsegs; j++){
          speeds[dist] = bspeed; 
          dist++; 
      }
  }
  for(int i = 0; i < 100; i++){
      //cout << speeds[i] << " " << limits[i] << "\n"; 
      ans = max(ans, speeds[i]-limits[i]);
  }
  fout << ans; 
}