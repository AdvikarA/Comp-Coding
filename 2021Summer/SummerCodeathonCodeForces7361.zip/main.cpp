#include <iostream>
using namespace std; 
typedef long long ll;
int main() {
    ll n; 
    cin >> n; 
    for(ll i = 0; i < n; i++){
        ll p; 
        cin >> p; 
        bool solved = false; 
        if(solved == false){
            for(ll a = 1; a < p; a++){
                if (solved == true){
                    break; 
                }
                for(ll b = a+1; b < p; b++){
                    if(solved == true){
                        break; 
                    }
                    ll mod1 = p%a;
                    ll mod2 = p%b;
                    if(mod1 == mod2){
                        solved = true; 
                        cout << a << " " << b << "\n"; 
                        
                    }
                }
            }
        }
    }
}