#include <iostream>
#include <fstream>
using namespace std;
int main() {
    ifstream fin ("paint.in");
    ofstream fout ("paint.out");
    int a, b, c, d, sum; 
    cin >> a >> b; 
    cin >> c >> d; 
    if (a < d || b < c){
        sum = (b-a + d-c); 
    }
    if (a < c){
        if(b < c){
            sum = b-a + d-c; 
        }
        else{
            sum = d-a; 
        }
    }
    else{
        if(d < a){
            sum = d-c + b-a; 
        }
        else{
            sum = b-c; 
        }
    }
    fout << sum; 
}