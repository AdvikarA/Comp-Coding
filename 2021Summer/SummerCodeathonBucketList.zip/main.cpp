#include <fstream>
using namespace std; 
int main() {
    ifstream fin("blist.in");
    ofstream fout("blist.out");
    int N; 
    fin >> N; 
    int ans = 0; 
    int time[1000] = {0}; 
    int start, end, bucket; 
    for(int i = 0; i < N; i++){
        fin >> start >> end >> bucket; 
        for(int j = start; j <= end; j++){
            time[j] += bucket; 
        }
    }
    for(int i = 0; i < 1000; i++){
        ans = max(ans, time[i]); 
    }
    fout << ans; 
}