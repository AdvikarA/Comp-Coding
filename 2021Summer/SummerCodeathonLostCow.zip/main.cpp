#include <fstream>
using namespace std;
int main() {
    ifstream fin("lostcow.in");
    ofstream fout("lostcow.out");
    int x, y; 
    fin >> x >> y; 
    bool dir = true; 
    int distance = 1; 
    int ans = 0; 
    if(y > x){
        while(x < y){
            
            if(dir){
                int x1 = x; 
                for(int i = x1; i <= x1+distance; i++){
                   // cout << x+distance; 
                    //cout << "up" << "\n"; 
                    ans++;
                    x++;
                    if(x == y){
                        break; 
                        //cout<< "i broke lol";
                    }
                }
                distance *= 2; 
                dir = false; 

            }
            else{
                int x1 = x;
                for(int i = x1; i >= x1-distance; i--){
                    //cout << "down" << "\n"; 
                    ans++; 
                    x--; 
                    if(x == y){
                        cout<< "i broke lol";
                        break; 
                    }
                    

                } 
                distance *= 2; 
                dir = true; 
                
            }
        }
    }
    else if(y < x){
        while(x > y){
            
            if(dir){
                int x1 = x; 
                for(int i = x1; i <= x1+distance; i++){
                   // cout << x+distance; 
                    //cout << "up" << "\n"; 
                    ans++;
                    x++;
                    if(x == y){
                        break; 
                        //cout<< "i broke lol";
                    }
                }
                distance *= 2; 
                dir = false; 

            }
            else{
                int x1 = x;
                for(int i = x1; i >= x1-distance; i--){
                    //cout << "down" << "\n"; 
                    ans++; 
                    x--; 
                    if(x == y){
                        cout<< "i broke lol";
                        break; 
                    }
                    

                } 
                distance *= 2; 
                dir = true; 
                
            }
        }
    }
    
    fout << ans; 
}