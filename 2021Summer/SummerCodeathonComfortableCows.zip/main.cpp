#include <iostream>
#include <fstream>
using namespace std; 
bool IsComfortable(int grid[1000][1000], int xxx, int yyy){
    int adjcows = 0; 
    if((grid[xxx+1][yyy]) == 1){
        adjcows++; 
    }
    if((grid[xxx-1][yyy]) == 1){
        adjcows++; 
    }
    if((grid[xxx][yyy+1]) == 1){
        adjcows++; 
    }
    if((grid[xxx][yyy-1]) == 1){
        adjcows++; 
    }
    if(adjcows == 3){
        return true; 
    }
    return false; 
}
int main() {
    int n; 
    cin >> n; 
    int x, y; 
    int ans; 
    int grid[1000][1000] = {0}; 
    for(int i = 0; i < n; i++){
        cin >> x >> y; 
       // cout << x << y; 
        ans = 0; 
        grid[x][y] = 1; 
        for(int xx = 0; xx < 1000; xx++){
            for(int yy = 0; yy < 1000; yy++){
                if(grid[xx][yy] == 1){
                    if(IsComfortable(grid, xx, yy) == true){
                        ans++;
                    }
                }
            }
        }
        cout << "\n" << ans; 
        
    }
    
}



//IsComfortable()
    //if element in adj boxes have cow  
        //adj cows++
    //if adj cows == 3
        //cow is said to be comfortable
        //return true
    //else
        //return false

//get n
//do thing n times
    //add new cow to grid
    //ans = 0
    //get coords
    //check every element in grid
        //if there is a cow, make it 1
    //check every box with cow
        //if IsComfortable == true
            //ans++
    