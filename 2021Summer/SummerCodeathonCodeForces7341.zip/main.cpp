#include <iostream>
using namespace std; 
int main() {
    int t; 
    cin >> t; 
    int smallest
    int x = 1; 
    int y = 2; 
    for(int i = 0; i < t; i++){
        int n; 
        cin >> n; 
        for(int j = 0; j < n; j++){
            for(int k = 0; k < n/2; k++){
                if((j*x + k*y) == n){
                    
                }
            }
        }

    }
}