#include <iostream>
#include <vector>
using namespace std;
int main(){
    int n = 100000;
    vector<int> v[100000];
    cout << "test";
}