#include <iostream>
#include<fstream>
#include <vector>
#include <algorithm>
#include <utility>
using namespace std; 
int main(){
    
}