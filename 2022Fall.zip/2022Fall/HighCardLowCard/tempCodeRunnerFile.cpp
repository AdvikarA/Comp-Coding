                bessie_second_half.push_back(i+1); 
