        cout << prefix[i] << " ";
