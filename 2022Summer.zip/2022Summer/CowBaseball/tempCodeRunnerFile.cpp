            upper1 = upper_bound(cows.begin()+a, cows.end(), g1*2);
