ifstream fin ("maxcross.in");
    ofstream fout ("maxcross.out");