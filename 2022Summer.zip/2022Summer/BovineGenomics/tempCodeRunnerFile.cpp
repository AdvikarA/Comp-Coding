                cout << a << "   " << b <<  "\n";
