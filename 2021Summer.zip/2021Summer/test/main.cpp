#include<iostream>
using namespace std; 
int main(){
    //ifstream fin("test.in");
    //ofstream fout("test.out"); 
    int a, b; 
    cin >> a >> b;
    cout << a << b; 
}