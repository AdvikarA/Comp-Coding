#include <iostream>
using namespace std; 
int main() {
    int n; 
    cin >> n; 
    int a[n]; 
    int b[n-1];
    
    int seta = 0; 
    for(int i = 0; i < n-1; i++){
        cin >> b[i]; 
    }
    for(int i = 1; i < b[0]; i++){
        a[0] = i; 
        for(int j = 1; j < n; j++){
            a[j] = b[j-1] - a[j-1]; 
            if(a[j]==a[j-1]){
                break; 
            } 
            else{
                if(j ==n-1){
                    for(int z = 0; z < n; z++){
                        cout << a[z]; 
                    }
                }
            }
        }

        
    }
}

// b1 = a1 + a2