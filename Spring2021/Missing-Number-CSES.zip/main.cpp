#include <iostream>
#include <algorithm> 
using namespace std; 
int main() {
  int n;
  int a[n-1];
  cin >> n; 
  for (int i = 0; i <= n-1; i++){
    cin >> a[i];

  }
  sort(a, a+n);
  for (int i = 0; i<=n-1; i++){
    if (a[i] + 1 != a[i+1]){
      cout << a[i]
    }
  }
}