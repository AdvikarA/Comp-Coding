#include <iostream>
#include <vector>
using namespace std; 
int main() {
    int rows, pos;
    int ans = 0; 
    cin >> rows >> pos;
    int ranks[rows][pos]; 
    for(int i = 0; i < rows; i++){
        for(int j = 0; j < pos; j++){
            cin >> ranks[i][j]; 
        }
    }
    for(int i = 0; i < pos; i++){
        for(int j = 0; j < pos; j++){
            int cow1 = ranks[0][i];
            int cow2 = ranks[0][j]; 
            int pairs = 0; 
            for(int k = 0; k < rows; k++){
                int cowindex1 = 0; 
                int cowindex2 = 0; 
                for(int z =0; z < pos; z++){
                    if(ranks[k][z]==cow1){
                        cowindex1 = z;
                    }
                    if(ranks[k][z]==cow2){
                        cowindex2 = z;
                    }
                }
                if(cowindex1 < cowindex2){
                    pairs++; 
                }
            }
            if(pairs == rows){
                ans++; 
            }
        }
    }
    cout <<ans; 
    
}