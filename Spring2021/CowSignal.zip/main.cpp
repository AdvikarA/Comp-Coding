#include <iostream>
#include <string>
using namespace std;
int main() {
    int m, n, k;  
    cin >> m >> n >> k; 
    bool canvas[10][10]; 
    for(int i = 0; i < m; i++){
        char rows[10]; 
        cin >> rows; 
        for(int j = 0; j < n; j++){
            if(rows[j] == 'X'){
                canvas[i][j] = true; 
            }
            else{
                canvas[i][j] = false; 
            }

        }
    }
     for(int i = 0; i < m; i++){
        for(int u = 0; u < k; u++){
            for(int j = 0; j < n; j++){
                for(int f = 0; f < k; f++){
                    if(canvas[i][j] == true){
                        cout << "X";
                    }
                    else{
                        cout << "."; 
                    }
                }
            }
            cout << endl; 
        }
     }
}