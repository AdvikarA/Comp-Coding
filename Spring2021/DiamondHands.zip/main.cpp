#include <fstream>
#include <algorithm>
using namespace std;
int main() {
    ifstream fin ("diamond.in");
    ofstream fout ("diamond.out");
    long long n, k;
    long long ans = 0; 
    fin >> n >> k;
    long long arr[n];
    for(int i = 0; i < n; i++){
        fin >> arr[i]; 
    }
    sort(arr, arr+n);
    for(int i = 0; i < n; i++){
        if(i != n-1){
            if(arr[i+1]-arr[i] > k){
                continue; 
            }
            else{
                ans++; 
            }
        }
    }
    fout << ans; 
}