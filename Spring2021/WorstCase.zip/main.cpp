#include <iostream>
using namespace std; 
int main() {
  cout << "B00" << endl << "1B0" <<endl <<"11B";
}