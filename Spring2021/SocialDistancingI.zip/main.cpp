#include <fstream>
using namespace std; 
#include <string>
int main() {
  fstream fin ("socdist1.in");
  fstream fout ("socdist.out"); 
  long long max;
  fin >> max; 
  long long oldi = 0; 
  long long distance =0; 
  long long secondbig = 0; 
  int newd; 
  string stalls;
  long long d =0; 
  for(int i = 0; i < max; i++){
    fin >> stalls[i];
  }
  for(int i = 0; i < max; i++){
    if(stalls[i] == '1'){
      distance = i - oldi;
      oldi = i;
      if(distance > d){
        d = distance; 
      }
      else if(distance > secondbig){
        secondbig = distance;  
      }
    }
  }
  if(secondbig %2 == 0){
    secondbig = secondbig/2;
  }
  else{
    secondbig = (secondbig+1)/2;
  }
  fout << secondbig; 
}