#include <iostream>
#include <fstream>
using namespace std;
int main() {
  ifstream fin ("breedflip.in");
  ofstream fout ("breedflip.out"); 
  int samegroup = 0;
  int wronggroup = 0; 
  int len; 
  fin >> len; 
  int want[len]; 
  int given[len]; 
  for(int i =0; i <len; i++){
    fin >> want[i];
  }
  for(int i =0; i <len; i++){
    fin >> given[i];
  }
  for(int i=0; i<len; i++){
    if(want[i] == given[i]){
      samegroup+=1; 
      if(i != len-1){
        if(want[i+1] == given[i+1]){
          samegroup -=1;
        }
      }
    }
    else{
      wronggroup +=1;
      if(i != len-1){
        if(want[i+1] != given[i+1]){
          wronggroup -=1;
        }
      }
    }
  }
  fout << max(samegroup, wronggroup);
}