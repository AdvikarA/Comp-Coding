#include <fstream>
#include <string>
using namespace std;
int main() {
  ifstream fin("buckets.in");
	ofstream fout("buckets.out")
  int brow;
  int bnum; 
  int startrow;
  int startnum; 
  string spaces[10][10];
  for (int i = 0; i < 10; i++){
    for (int a = 0; a < 10; a++){
      fin >> spaces[i][a]; 
      if (spaces[i][a] == "B"){
        brow = i; 
        bnum = a; 
      if (spaces[i][a] == "L"){
        startrow = i; 
        startnum = a; 
      }
      }
    }
  }
  int answer = abs(bnum - startnum) + abs(brow - startrow) - 1; 
  fout << answer; 
}