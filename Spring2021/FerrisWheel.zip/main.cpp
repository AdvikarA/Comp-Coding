#include <iostream>
#include <vector>
#include <algorithm>
using namespace std; 
int main() {
    int n, x, temp; 
    int ans = 0; 
    vector<int> weights; 
    cin >> n >> x; 
    for(int i = 0; i < n; i++){
        cin >> temp; 
        weights.push_back(temp);
    }
    sort(weights.begin(), weights.end());
    for (size_t i = 0; i < weights.size()-1; ++i) {
        if (weights[i] + weights[i+1] <= x){ 
            cout << "less"; 
            ans++; 
        }
        else{
            cout << "more"; 
            ans++; 
        }
} 
    cout << ans; 
}