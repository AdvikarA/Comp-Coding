#include <iostream>
#include <set>
using namespace std; 
int main() {
  int n, m, k; 
  int temp; 
  int ans = 0; 
  multiset<int> price; 
  cin >> n >> m >>k; 
  int want[n]; 
  for(int i = 0; i < n; i++){
    cin >> want[i]; 
  }
  for(int i = 0; i < m; i++){
    cin >> temp; 
    price.insert(temp); 
  }
  for(int i = 0; i < m; i++){
    auto it = price.lower_bound(want[i]-k);
    if(it == price.end()){
      continue; 
    }
    else if(*it > want[i]+k){
      continue; 
    }
    else{
      ans++; 
      price.erase(it); 
    }
  }
  cout << ans; 
}

// 30
//25
//35
