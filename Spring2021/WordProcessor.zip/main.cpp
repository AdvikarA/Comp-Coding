#include <iostream>
#include <string> 
using namespace std; 

int main() {
  int n; 
  int k;
  int charsinline = 0; 
  cin >> n >> k; 
  string words[n]; 
  for (int i = 0; i < 11; i++){
    cin >> words[i];
    if(i == 0){
      cout << words[i];
      charsinline += words[i].size();
    }
    else{
      if(words[i].size() + charsinline <= k){
        cout  << ' ' << words[i];
        charsinline += words[i].size();
      }
      else{
        cout << endl << words[i];
        charsinline = words[i].size(); 
      }
    }

  }

  
}