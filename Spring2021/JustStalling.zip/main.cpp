#include <iostream>
using namespace std; 
#include <algorithm>
int main() {
  int max;
  int index =0;
  int combo =0;
  int perms = 1; 
   
  cin >> max;
  int maxlist[max];
  int heights[max];
  for(int i = 0; i<max; i++){
    cin >> maxlist[i];
  }
  for(int i = 0; i<max; i++){
    cin >> heights[i];
  }
  for(int i = max-1; i >= 0; i--){
    for(int j = 0; j < max; j++){
      if(maxlist[i] <= heights[j]){
        combo = combo + 1; 
      }
    }
    combo= combo- index; 
    index = index + 1; 
    perms = perms * combo;
    combo = 0; 
  } 
  cout << perms; 
}