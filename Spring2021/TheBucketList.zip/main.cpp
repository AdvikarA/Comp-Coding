#include <iostream>
using namespace std;

int main() {
  int numofcows;
  int index; 
  int tbuckets =0; 
  int lowesttime = 1000; 
  cin >> numofcows;
  int s_time[numofcows];
  int t_time[numofcows]; 
  int buckets[numofcows];
  for (int i =0; i < numofcows; i++){
    cin >> s_time[i] >> t_time[i] >> buckets[i];
  }
  for(int i =0; i < numofcows; i++){
    if(s_time[i] < lowesttime){
      index = i; 
      lowesttime = s_time[i];
    }
  }
  for(int i =0; i < numofcows; i++){
    if(t_time[index] < s_time[i] && t_time[index != s_time[i]]){
      tbuckets += buckets[index]; 
    }
    else{
      tbuckets=buckets[index]+buckets[i];
    }
  }
  cout << tbuckets; 
}
