#include <iostream>
#include <algorithm>
using namespace std; 
int maxoc(int i, int n, int list[]){
  int occurence = 0; 
  for(int j = 0; j < n; j++){
    if(i <= list[j]){
      occurence++; 
    }
  }
  return occurence; 
}
int main() {
  int n, l; 
  cin >> n >> l; 
  int work[n]; 
  int max = 0; 
  for(int i = 0; i < n; i++){
    cin >> work[i]; 
  }
  int occurence = 0; 
  int counter = 0; 
  sort(work, work+n); 
  if(l != 0){
    for(int i =0; i < l; i++){
      for(int j = 0; j < n; j++){
        work[j]+=1; 
        l-=1; 
        occurence = maxoc(work[j], n, work);
        if(occurence > max){
          if(work[j] > max){
            max = work[j]; 
          } 
        }
      }
    }
  }
  else{
    for(int i = 0; i <n; i++){
      occurence = maxoc(work[i], n, work);
      if(occurence > max){
        if(work[i] > max){
          max = work[i]; 
        } 
      }
    }
    
  }
  cout << max; 
}
