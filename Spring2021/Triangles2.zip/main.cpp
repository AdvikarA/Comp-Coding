#include <iostream>
#include <fstream>
using namespace std; 
int main() {
    ifstream fin ("triangles.in");
    ofstream fout ("triangles.out"); 
    long long n; 
    fin >> n; 
    long long high = 0; 
    long long xdist, ydist; 
    long long x[n]; 
    long long y[n]; 
    for(int i = 0; i < n; i++){
        fin >> x[i] >> y[i]; 
    }
    for(int i = 0; i < n; i++){
        for(int j = i+1; j < n; j++){
            if(x[i] == x[j]){
                ydist = abs(y[i] - y[j]); 
            }
            if(y[i] == y[j]){
                xdist = abs(x[i] - x[j]); 
            }
            high = max(high, xdist*ydist);
        }
    }
    fout << high; 
}