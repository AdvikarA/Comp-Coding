                cout << cows[cowhit] << " " << cows[cowhit+1] << " " << cows[cowhit]+radius << "\n";
