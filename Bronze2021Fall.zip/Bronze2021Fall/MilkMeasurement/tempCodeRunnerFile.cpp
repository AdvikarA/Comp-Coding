        fout << " " << j << " " << maxcownum << " " << cows["Bessie"] << " " << cows["Elsie"] << " " << cows["Mildred"]  << " " << oldb << " " << olde << " " << oldm <<"\n";
