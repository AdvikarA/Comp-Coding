    cout << chance <<"/"<<totals<<"\n";
