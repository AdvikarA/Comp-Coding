#include <iostream>
using namespace std;
int main(){
    cout << 2<<endl<<4<<endl<<6<<endl<<2<<endl<<0<<endl<<0<<endl<<6;
}